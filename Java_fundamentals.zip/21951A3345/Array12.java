/*Given 2 int arrays, a and b, each length 3, form a new array of length 2, containing their middle elements.

middleWay([1, 2, 3], [4, 5, 6]) → [2, 5]
middleWay([7, 7, 7], [3, 8, 0]) → [7, 8]
middleWay([5, 2, 9], [1, 4, 5]) → [2, 4]*/
import java.util.*;
class Array12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] a = new int[3];
		int[] b=new int[3];
        for (int i = 0; i < 3; i++) {
            a[i] = scanner.nextInt();
        }
		for (int i = 0; i < 3; i++){
			b[i]=scanner.nextInt();
		}
		int [] new_array=new int[2];
		new_array[0]=a[1];
		new_array[1]=b[1];
		System.out.println(Arrays.toString(new_array));
	}
}
		
		