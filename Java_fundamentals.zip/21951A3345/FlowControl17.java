/* write a java program to find if the given number is palindrome or not

Example1:
c:\java Sample 110011
o/p:ll0011 is a palindrome

example 2:
c:\java sample 1234
o/p:1234 is not a palindrome

*/

public class Sample {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Please enter an integer number");
        } else {
            try {
                int num = Integer.parseInt(args[0]);
                int originalNum = num;
                int reversedNum = 0;

                while (num != 0) {
                    int digit = num % 10;
                    reversedNum = reversedNum * 10 + digit;
                    num /= 10;
                }
                if (originalNum == reversedNum) {
                    System.out.println(originalNum + " is a palindrome");
                } else {
                    System.out.println(originalNum + " is not a palindrome");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer number");
            }
        }
    }
}
