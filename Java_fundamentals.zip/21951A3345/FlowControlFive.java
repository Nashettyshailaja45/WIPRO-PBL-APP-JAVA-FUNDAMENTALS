/*
Initialize a character variable in a program and print 'Alphabet' if the initialized value is an alphabet,
print 'Digit' if the initialized value is a number,and 
print 'Special Character',if the initialized value is anything else.
*/
public class FlowControlFive{
	public static void main(String[]args){
		char c='a';
		if(c>='0' && c<='9'){
			System.out.println("Digit");
		}
		else if((c>='a' && c<='z')||(c>='A' && c<='Z')){
			System.out.println("Alphabhet");
		}
		else{
			System.out.println("Special Character");
		}
	}
}