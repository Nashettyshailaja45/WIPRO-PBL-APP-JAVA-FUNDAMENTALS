/*
Write a program to check if the program has recieved command line arguments or not.
if the program has not recieved arguments then print "No Values",else print all the
values in a single line separated by,(comma)
Example 1
java example
o/p: NO Values

Example 2
java Example Mumbai Banglore
o/p:Mumbai,Banglore
*/

public class FlowControlThree{
	public static void main(String[] args){
		if(args.length==0){
			System.out.println("No Values");
		}
		else{
			String result = String.join(",", args);
			System.out.println(result);
		}
	}
}
