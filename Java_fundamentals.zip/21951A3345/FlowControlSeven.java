/*
if the character value is in lowercase,the output should be displayed in uppercas in the following format
Example 1:
i/p:a
o/p:a->
f the character value is in uppercase,the output should be displayed in lowercase in the following format
Example 2:
i/p:A
o/p:A->a
*/

public class FlowControlSeven{
    public static void main(String[] args) {
        char check= 'z';
        int result;
        if(check>=65 && check<=90){
            result = check + 32;
            System.out.println(check+" -> "+(char)result);
        }else if(check>=97 && check<=122){
            result = check - 32;
            System.out.println(check+" -> "+(char)result);
        }
    }
}
	