/* Write a program to reverse the elements of a given 2*2 array. Four integer numbers needs to be passed as Command Line arguments.

Example1)
C:\>java Sample 1 2 3
O/P: Please enter 4 integer numbers

Example2)
C:\>java Sample 1 2 3 4
O/P: 
 The given array is :
  1 2 
  3 4 
 The reverse of the array is :
  4 3 
  2 1*/
import java.util.*;
class Array13{
	public static void main(String args[]){
		int[][] originalArray = new int[2][2];
        int index = 0;
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                originalArray[i][j] = Integer.parseInt(args[index++]);
            }
        }
		int [][]reversedArray=new int[2][2];
		reversedArray[0][0] = originalArray[1][1];
        reversedArray[0][1] = originalArray[1][0];
        reversedArray[1][0] = originalArray[0][1];
        reversedArray[1][1] = originalArray[0][0];
		for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(reversedArray[i][j] + " ");
            }
            System.out.println();
        }
	}
}