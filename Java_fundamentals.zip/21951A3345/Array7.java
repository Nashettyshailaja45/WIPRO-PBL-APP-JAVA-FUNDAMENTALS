/* Write a program to remove the duplicate elements in an array and print the same.
Example)
I/P:{12,34,12,45,67,89}
O/P:{12,34,45,67,89}*/
import java.util.*;

public class Array7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        int[] numbers = new int[size];
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }
        Set<Integer> uniqueElements = new HashSet<>();
        List<Integer> nonDuplicateList = new ArrayList<>();
        for (int number : numbers) {
            if (uniqueElements.add(number)) {
                nonDuplicateList.add(number);
            }
        }
        for (int element : nonDuplicateList) {
            System.out.print(element + " ");
        }
    }
}
