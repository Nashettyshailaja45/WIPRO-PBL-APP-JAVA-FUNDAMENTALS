/*
initialize two character variables in a program and display the characters in alphabetical order.

Example 1
if the first character is 's' and second character is 'e' then the output should be e,s
example 2
if the first character is 'a' and second character is 'e', then the output should be a,e

*/

public class FlowControlFour{
	public static void main(String[]args){
		char a='d';
		int m=a;
		char b='s';
		int n=b;
		if(m<n){
			System.out.println(a+","+b);
		}
		else{
			System.out.println(b+","+a);
		}
	}
}
			
		