/*
Write a program to check if a given integer number is even or odd
*/

public class FlowControlTwo{
	public static void main(String args[]){
		int n=9;
		if(n%2==0){
			System.out.println("even");
		}
		else{
			System.out.println("odd");
		}
	}
}