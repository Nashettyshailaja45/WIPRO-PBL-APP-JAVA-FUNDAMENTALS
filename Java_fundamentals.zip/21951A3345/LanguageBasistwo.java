/*
Write a program to accept a string as a command line argument and print a welcome message
as given below.
example1:
c:\>java sample john
o/p expected:welcome john
*/

public class LanguageBasistwo{
    public static void main(String[] args) {
        System.out.println("Welcome "+args[0]);
    }
}
