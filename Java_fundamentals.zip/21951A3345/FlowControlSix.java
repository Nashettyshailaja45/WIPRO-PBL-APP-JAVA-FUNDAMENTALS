/*
write a program to accpet gender ("male" or "female")and age from command line arguments and print age from command line arguments and print the
percentage of interest based on the given conditions.
if the gender is 'female' and age is between 1 and 58,the percentage of interestis 8,2%.
if the gender is 'female' and age is between 59 and 100,the percentage of interest is 9.2%.
if the gender is 'male' and age is between 1 and 58,the percentage of interestis 8.4%.
if the gender is 'male' and age is between 59 and 100,the percentage of interestis 10.5%.
*/
public class FlowControlSix{
	public static void main(String[] args){
		String gender=args[0];
		int age=Integer.parseInt(args[1]);
		if(gender.equals("Female") && (age>=1 && age<=58)){
			System.out.println("8.2%");
		}
		else if (gender.equals("Female") && (age>=59 && age<=100)){
			System.out.println("9.2%");
		}
		else if(gender.equals("male") && (age>=1 && age<=58)){
			System.out.println("8.4");
		}
		else{
			System.out.println("10.5%");
		}
	}
}