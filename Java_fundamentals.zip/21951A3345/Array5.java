import java.util.Arrays;
import java.util.Scanner;

public class Array5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        int[] numbers = new int[size];
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }
        Arrays.sort(numbers);
        System.out.println("Largest two numbers: " + numbers[size - 1] + ", " + numbers[size - 2]);
        System.out.println("Smallest two numbers: " + numbers[0] + ", " + numbers[1]);
    }
}
