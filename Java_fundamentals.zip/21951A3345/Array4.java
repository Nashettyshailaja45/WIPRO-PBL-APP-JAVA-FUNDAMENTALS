/* Initialize an integer array with ascii values and print the corresponding character values in a single row.*/
import java.util.Scanner;

public class Array4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        int[] asciiValues = new int[size];
        for (int i = 0; i < size; i++) {
            asciiValues[i] = scanner.nextInt();
        }
        for (int asciiValue : asciiValues) {
            char character = (char) asciiValue;
            System.out.print(character + " ");
        }
        System.out.println(); 

    }
}
