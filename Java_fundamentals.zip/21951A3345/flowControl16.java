/*write a program to reverse a given number and print

example 1:
i/p:1234
o/p:4321

example 2:
i/p:1004
o/p:4001
*/
public class FlowControl16 {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Please enter an integer number");
        } else {
            try {
                int num = Integer.parseInt(args[0]);
                int reversedNum = 0;

                while (num != 0) {
                    int digit = num % 10;
                    reversedNum = reversedNum * 10 + digit;
                    num /= 10;
                }

                System.out.println(reversedNum);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer number");
            }
        }
    }
}

