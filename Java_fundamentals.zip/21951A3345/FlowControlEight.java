/*Write a program to recieve a color code from the user(an alphabhet).
the program should then print the color name,based on the color code given
the following are the color codes and their corresponding color names.
R->red,B=>blue,G->green,0->orange,Y->yellow,W->white.
if color code provided by the user is not valid then print "invalid code:.
*/

import java.util.Scanner;

public class FlowControlEight {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        if(s.equals("R")) {
            System.out.println("Red");
        } else if(s.equals("B")) {
            System.out.println("Blue");
        } else if(s.equals("G")) {
            System.out.println("Green");
        } else if(s.equals("O")) {
            System.out.println("Orange");
        } else if(s.equals("Y")) {
            System.out.println("Yellow");
        } else if(s.equals("W")) {
            System.out.println("White");
        } else {
            System.out.println("Invalid Code");
        }
    }
}
