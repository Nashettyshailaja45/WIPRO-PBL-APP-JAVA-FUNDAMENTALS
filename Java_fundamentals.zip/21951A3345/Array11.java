/*Given an array of type int, print true if every element is 1 or 4. 

only14([1, 4, 1, 4]) → true
only14([1, 4, 2, 4]) → false
only14([1, 1]) → true*/
import java.util.Scanner;
class Array11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        int[] numbers = new int[size];
        for (int i = 0; i < size; i++) {
            numbers[i] = scanner.nextInt();
        }
		int c=0;
		for(int i=0;i<size;i++){
			if(numbers[i]==1 || numbers[i]==4){
				c++;
			}
		}
		if(c==size){
			System.out.println("True");
		}
		else{
			System.out.println("False");
		}
	}
}