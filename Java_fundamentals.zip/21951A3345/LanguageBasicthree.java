/*
write a program to accept two integers as command line arguments and print the sum
of the two numbers.
Example 1:
c:/> java sample 10 20
o/p expected: the sum of 10 and 20 is 30
*/

public class LanguageBasicthree{
	public static void main(String[] args){
		int r=Integer.parseInt(args[0])+Integer.parseInt(args[1]);
		System.out.println("The sum of "+args[0]+" and "+args[1]+" is "+r);
	}
}