/*write a program that accepts two strings as command line arguments and generate the output in the required format.

Example 1:
if the two command line arguments are wipro and banglore then the output generate should be wipro technologies banglore.
Example 2:
if the two command line arguments are ABC and MUMBAI then the output generate should be ABC technologies MUMBAI.
*/

class LanguagBasicsOne{
    public static void main(String[] args) {
        System.out.println(args[0]+" Technologies "+args[1]);
    }
}