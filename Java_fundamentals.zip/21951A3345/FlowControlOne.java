/*
A
write a program to check if a given integer number is positive,negative or zero


class FlowControlOne{
	public static void main(String args[]){
		int n=7;
		if(n>0){
			
			System.out.println("Positive");
		}
		else if(n<0){
			System.out.println("Negative");
		}
		else{
			System.out.println("Zero");
		}
	}
}
*/


/*
B
given two non-negative int values,print true if they have the same last digit,such
as write 27 and 57.
             lastDigit(7,17)=>true 
			 lastDigit(617)=>false
			 lastDigit(3,13)=>true
*/
public class FlowControlOne{
	public static void main(String args[]){
		int n1=17;
		int n2=6;
		if(n1%10 == n2%10){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
	}
}